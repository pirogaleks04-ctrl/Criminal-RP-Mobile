extends CharacterBody3D

@export var walk_speed: float = 4.2
@export var jump_velocity: float = 4.5
@export var look_sensitivity: float = 0.004

var gravity: float = 12.0
var camera_pivot: Node3D
var camera: Camera3D

func _ready() -> void:
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.38
	capsule.height = 1.75
	var body_mesh := MeshInstance3D.new()
	body_mesh.mesh = capsule
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.18, 0.24, 0.34)
	body_mesh.material_override = material
	body_mesh.position.y = 0.9
	add_child(body_mesh)
	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.38
	shape.height = 1.75
	collision.shape = shape
	collision.position.y = 0.9
	add_child(collision)
	camera_pivot = Node3D.new()
	camera_pivot.position = Vector3(0, 1.55, 0)
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 1.0, 5.8)
	camera.rotation_degrees.x = -9
	camera.current = true
	camera_pivot.add_child(camera)

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		if Input.is_action_just_pressed("jump"):
			velocity.y = jump_velocity
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var forward := -global_transform.basis.z
	var right := global_transform.basis.x
	var direction := (right * input_dir.x + forward * -input_dir.y).normalized()
	if direction.length() > 0.05:
		velocity.x = direction.x * walk_speed
		velocity.z = direction.z * walk_speed
		var target_yaw := atan2(-direction.x, -direction.z)
		rotation.y = lerp_angle(rotation.y, target_yaw, delta * 8.0)
	else:
		velocity.x = move_toward(velocity.x, 0.0, walk_speed * 5.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, walk_speed * 5.0 * delta)
	move_and_slide()
	global_position.x = clamp(global_position.x, -42.0, 42.0)
	global_position.z = clamp(global_position.z, -42.0, 42.0)

func apply_camera_drag(relative: Vector2) -> void:
	rotate_y(-relative.x * look_sensitivity)
	camera_pivot.rotation.x = clamp(camera_pivot.rotation.x - relative.y * look_sensitivity, -0.55, 0.35)
