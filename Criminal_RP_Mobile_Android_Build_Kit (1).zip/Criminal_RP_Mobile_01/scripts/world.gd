extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const UI_SCRIPT = preload("res://scripts/touch_controls.gd")

func _ready() -> void:
	_build_environment()
	_build_city()
	_spawn_player()
	_build_ui()

func _material(color: Color) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 1.0
	return mat

func _box(parent: Node3D, name: String, pos: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.name = name
	body.position = pos
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.material_override = _material(color)
	body.add_child(mesh)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	parent.add_child(body)

func _build_environment() -> void:
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Sky.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.76, 0.82)
	env.ambient_light_energy = 0.65
	world_env.environment = env
	add_child(world_env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.1
	sun.shadow_enabled = false
	add_child(sun)
	_box(self, "Ground", Vector3(0, -0.35, 0), Vector3(100, 0.5, 100), Color(0.24, 0.43, 0.25))
	_box(self, "MainRoad", Vector3(0, -0.06, 0), Vector3(15, 0.12, 100), Color(0.12, 0.13, 0.15))
	_box(self, "CrossRoad", Vector3(0, -0.05, 0), Vector3(100, 0.13, 14), Color(0.12, 0.13, 0.15))
	for z in range(-40, 45, 8):
		_box(self, "RoadMark", Vector3(0, 0.02, z), Vector3(0.28, 0.025, 3.2), Color(0.9, 0.82, 0.52))

func _build_city() -> void:
	var colors := [Color(0.68, 0.57, 0.46), Color(0.57, 0.62, 0.65), Color(0.72, 0.68, 0.57), Color(0.48, 0.52, 0.56)]
	var idx := 0
	for x in [-28.0, -17.0, 17.0, 28.0]:
		for z in [-30.0, -12.0, 12.0, 30.0]:
			var h := 8.0 + float((idx * 7) % 13)
			var w := 7.5
			_box(self, "DowntownBuilding_%02d" % idx, Vector3(x, h * 0.5, z), Vector3(w, h, 9.0), colors[idx % colors.size()])
			_box(self, "Roof_%02d" % idx, Vector3(x, h + 0.25, z), Vector3(w + 0.2, 0.5, 9.2), Color(0.25, 0.27, 0.3))
			idx += 1
	# Sidewalks and a simple plaza
	_box(self, "WestSidewalk", Vector3(-9.2, 0.03, 0), Vector3(3.2, 0.2, 100), Color(0.55, 0.53, 0.48))
	_box(self, "EastSidewalk", Vector3(9.2, 0.03, 0), Vector3(3.2, 0.2, 100), Color(0.55, 0.53, 0.48))
	_box(self, "Plaza", Vector3(0, 0.02, -20), Vector3(13, 0.18, 10), Color(0.62, 0.59, 0.52))
	# Decorative palm-like trunks and crowns
	for p in [Vector3(-11, 0, -25), Vector3(11, 0, -25), Vector3(-11, 0, 0), Vector3(11, 0, 0), Vector3(-11, 0, 25), Vector3(11, 0, 25)]:
		_box(self, "PalmTrunk", p + Vector3(0, 2.1, 0), Vector3(0.35, 4.2, 0.35), Color(0.38, 0.25, 0.13))
		var crown := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 1.5
		sphere.height = 2.2
		crown.mesh = sphere
		crown.material_override = _material(Color(0.16, 0.38, 0.18))
		crown.position = p + Vector3(0, 4.4, 0)
		add_child(crown)

func _spawn_player() -> void:
	var player := CharacterBody3D.new()
	player.name = "Player"
	player.set_script(PLAYER_SCRIPT)
	player.position = Vector3(0, 0.15, 18)
	add_child(player)
	# Parked demonstration car made from simple primitive meshes.
	var car := Node3D.new()
	car.position = Vector3(4.5, 0.15, 16)
	add_child(car)
	var chassis := MeshInstance3D.new()
	var chassis_mesh := BoxMesh.new()
	chassis_mesh.size = Vector3(2.0, 0.65, 3.8)
	chassis.mesh = chassis_mesh
	chassis.material_override = _material(Color(0.55, 0.12, 0.10))
	chassis.position.y = 0.65
	car.add_child(chassis)
	var cabin := MeshInstance3D.new()
	var cabin_mesh := BoxMesh.new()
	cabin_mesh.size = Vector3(1.55, 0.7, 1.8)
	cabin.mesh = cabin_mesh
	cabin.material_override = _material(Color(0.16, 0.22, 0.27))
	cabin.position = Vector3(0, 1.28, -0.15)
	car.add_child(cabin)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var controls := Control.new()
	controls.name = "TouchControls"
	controls.set_script(UI_SCRIPT)
	controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(controls)
