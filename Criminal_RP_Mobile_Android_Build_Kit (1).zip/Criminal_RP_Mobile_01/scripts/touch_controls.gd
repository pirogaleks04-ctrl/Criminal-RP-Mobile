extends Control

var joystick_active := false
var joystick_origin := Vector2.ZERO
var joystick_vector := Vector2.ZERO
var look_touch_index := -1
var player: CharacterBody3D
var jump_button_rect := Rect2()

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	player = get_node_or_null("/root/Main/Player")
	queue_redraw()

func _process(_delta: float) -> void:
	if player == null:
		player = get_node_or_null("/root/Main/Player")
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	var size := get_viewport_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < size.x * 0.48 and event.position.y > size.y * 0.48:
				joystick_active = true
				joystick_origin = event.position
				joystick_vector = Vector2.ZERO
				accept_event()
			elif event.position.x > size.x * 0.52 and event.position.y > size.y * 0.35:
				if Rect2(Vector2(size.x - 150, size.y - 150), Vector2(130, 130)).has_point(event.position):
					Input.action_press("jump")
				else:
					look_touch_index = event.index
				accept_event()
		else:
			if joystick_active:
				joystick_active = false
				joystick_vector = Vector2.ZERO
				_release_movement()
			if look_touch_index == event.index:
				look_touch_index = -1
			Input.action_release("jump")
			accept_event()
	elif event is InputEventScreenDrag:
		if joystick_active:
			joystick_vector = (event.position - joystick_origin).limit_length(62.0) / 62.0
			_update_movement()
			accept_event()
		elif look_touch_index == event.index and player != null:
			player.apply_camera_drag(event.relative)
			accept_event()

func _update_movement() -> void:
	_set_action("move_left", joystick_vector.x < -0.22)
	_set_action("move_right", joystick_vector.x > 0.22)
	_set_action("move_forward", joystick_vector.y < -0.22)
	_set_action("move_back", joystick_vector.y > 0.22)

func _release_movement() -> void:
	for action in ["move_left", "move_right", "move_forward", "move_back"]:
		Input.action_release(action)

func _set_action(action: String, pressed: bool) -> void:
	if pressed:
		Input.action_press(action)
	else:
		Input.action_release(action)

func _draw() -> void:
	var size := get_viewport_rect().size
	var base := joystick_origin if joystick_active else Vector2(112, size.y - 112)
	draw_circle(base, 66, Color(0.05, 0.07, 0.10, 0.34))
	draw_arc(base, 66, 0, TAU, 48, Color(1, 1, 1, 0.5), 3)
	draw_circle(base + joystick_vector * 43.0, 27, Color(0.88, 0.91, 0.95, 0.65))
	var jump_center := Vector2(size.x - 86, size.y - 86)
	draw_circle(jump_center, 48, Color(0.10, 0.12, 0.15, 0.42))
	draw_arc(jump_center, 48, 0, TAU, 48, Color(1, 1, 1, 0.65), 3)
	draw_string(ThemeDB.fallback_font, jump_center + Vector2(-19, 7), "JUMP", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color.WHITE)
	draw_string(ThemeDB.fallback_font, Vector2(20, 34), "CRIMINAL RP  •  TEST 0.1", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
